export const initCheckout = () => {
  document.querySelector('body').classList.add('checkout-page')
  console.log('add body class')
}